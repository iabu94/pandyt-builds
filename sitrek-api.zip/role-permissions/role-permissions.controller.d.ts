import { Response } from 'express';
import { RolePermissionsService } from './role-permissions.service';
export declare class RolePermissionsController {
    private readonly service;
    constructor(service: RolePermissionsService);
    findAll(response: Response): Promise<Response<any, Record<string, any>>>;
}
