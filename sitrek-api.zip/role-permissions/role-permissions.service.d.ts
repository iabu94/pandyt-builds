import { DataSource } from 'typeorm';
import { RolePermission } from './entities/role-permissions.entity';
export declare class RolePermissionsService {
    private dataSource;
    constructor(dataSource: DataSource);
    findAll(): Promise<RolePermission[]>;
}
