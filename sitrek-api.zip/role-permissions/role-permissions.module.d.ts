export declare class RolePermissionsModule {
}
