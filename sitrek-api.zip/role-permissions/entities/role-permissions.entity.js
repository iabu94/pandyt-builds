"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RolePermission = void 0;
class RolePermission {
}
exports.RolePermission = RolePermission;
//# sourceMappingURL=role-permissions.entity.js.map