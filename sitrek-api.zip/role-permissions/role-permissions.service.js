"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RolePermissionsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("typeorm");
const tableName = 'sitrek_permissions';
let RolePermissionsService = class RolePermissionsService {
    constructor(dataSource) {
        this.dataSource = dataSource;
    }
    async findAll() {
        const result = await this.dataSource.query(`SELECT 
    r.id AS id,
    r.name AS name,
    r.description AS description,
    CONCAT('[', GROUP_CONCAT(
        CONCAT('{"id": ', p.id, ', "name": "', p.name, '", "description": "', p.description, '"}')
    ), ']') AS permissions
FROM 
    sitrek_roles r
LEFT JOIN 
    sitrek_permissions p ON r.id = p.roleId
GROUP BY 
    r.id, r.name;`);
        return result.map((role) => ({
            ...role,
            permissions: role.permissions ? JSON.parse(role.permissions) : [],
        }));
    }
};
exports.RolePermissionsService = RolePermissionsService;
exports.RolePermissionsService = RolePermissionsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeorm_1.DataSource])
], RolePermissionsService);
//# sourceMappingURL=role-permissions.service.js.map