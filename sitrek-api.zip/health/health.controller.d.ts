export declare class HealthController {
    findAll(): {
        status: string;
    };
}
