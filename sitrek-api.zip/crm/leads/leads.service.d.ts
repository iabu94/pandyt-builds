import { sitrek_leads } from '@prisma/client';
import { PrismaService } from 'src/prisma.service';
import { DataSource } from 'typeorm';
import { CustomersService } from '../customers/customers.service';
import { CreateLeadPayload, UpdateLeadPayload } from './dto/create-lead.dto';
import { Lead } from './entities/lead.entity';
export declare class LeadsService {
    private dataSource;
    private prisma;
    private customerService;
    constructor(dataSource: DataSource, prisma: PrismaService, customerService: CustomersService);
    create(payload: CreateLeadPayload): Promise<Lead>;
    getAll(): Promise<sitrek_leads[]>;
    findAll(): Promise<Lead[]>;
    findById(leadId: number): Promise<Lead | null>;
    findNotes(leadId: number): Promise<any>;
    update(data: UpdateLeadPayload): Promise<void>;
    getById(leadId: any): Promise<{
        followups: ({
            josyd_users: {
                params: string;
                id: number;
                name: string;
                username: string;
                email: string;
                password: string;
                block: number;
                sendEmail: number | null;
                registerDate: Date;
                lastvisitDate: Date;
                activation: string;
                lastResetTime: Date;
                resetCount: number;
                otpKey: string;
                otep: string;
                requireReset: number;
                isBranchDefault: number;
                isAllowedToRS: number;
                isAllowedToRSDate: Date;
                blockRSnRECP: number;
                isAllowedToRS2: number;
                isAllowedToRSDate2: Date;
            };
        } & {
            id: number;
            leadId: number;
            customerId: number | null;
            status: string;
            note: string;
            contactDate: Date;
            contactById: number;
        })[];
        rateCards: {
            id: number;
            leadId: number;
            customerId: number | null;
            demarcation: string;
            catogory: string;
            paymentType: string;
            initialRate: import("@prisma/client/runtime/library").Decimal;
            additionalRate: import("@prisma/client/runtime/library").Decimal;
        }[];
        attachments: {
            id: number;
            leadId: number;
            customerId: number | null;
            fullUrl: string;
            verifiedById: number | null;
            status: string;
        }[];
        notes: {
            id: number;
            leadId: number;
            customerId: number | null;
            note: string;
            title: string;
        }[];
        city: {
            sitrek_districts: {
                id: number;
                name: string;
                provinceId: number;
            };
        } & {
            id: number;
            name: string;
            districtId: number;
            postalCode: string;
        };
        sitrek_cities: {
            sitrek_districts: {
                id: number;
                name: string;
                provinceId: number;
            };
        } & {
            id: number;
            name: string;
            districtId: number;
            postalCode: string;
        };
        sitrek_lead_attachments: {
            id: number;
            leadId: number;
            customerId: number | null;
            fullUrl: string;
            verifiedById: number | null;
            status: string;
        }[];
        sitrek_lead_followups: ({
            josyd_users: {
                params: string;
                id: number;
                name: string;
                username: string;
                email: string;
                password: string;
                block: number;
                sendEmail: number | null;
                registerDate: Date;
                lastvisitDate: Date;
                activation: string;
                lastResetTime: Date;
                resetCount: number;
                otpKey: string;
                otep: string;
                requireReset: number;
                isBranchDefault: number;
                isAllowedToRS: number;
                isAllowedToRSDate: Date;
                blockRSnRECP: number;
                isAllowedToRS2: number;
                isAllowedToRSDate2: Date;
            };
        } & {
            id: number;
            leadId: number;
            customerId: number | null;
            status: string;
            note: string;
            contactDate: Date;
            contactById: number;
        })[];
        sitrek_lead_notes: {
            id: number;
            leadId: number;
            customerId: number | null;
            note: string;
            title: string;
        }[];
        sitrek_rate_cards: {
            id: number;
            leadId: number;
            customerId: number | null;
            demarcation: string;
            catogory: string;
            paymentType: string;
            initialRate: import("@prisma/client/runtime/library").Decimal;
            additionalRate: import("@prisma/client/runtime/library").Decimal;
        }[];
        id: number;
        provinceId: number;
        ownerId: number;
        leadtype: string;
        leadStatus: string;
        salesPersonId: number;
        orgName: string;
        orgIdType: string;
        orgId: string;
        addrTitles: string;
        isDeleted: boolean;
        addr1: string;
        addr2: string;
        cityId: number;
        country: string;
        contactNIC: string;
        contactName: string;
        contactDesignation: string;
        contactEmail: string;
        contact1: string;
        contact2: string;
        adminFee: import("@prisma/client/runtime/library").Decimal;
        adminFeeType: string;
        vat: import("@prisma/client/runtime/library").Decimal;
        sscl: import("@prisma/client/runtime/library").Decimal;
        svat: import("@prisma/client/runtime/library").Decimal;
        discount: import("@prisma/client/runtime/library").Decimal;
        discountType: string;
        startDate: Date | null;
        endDate: Date | null;
    }>;
    deleteRateCard(cat: string, leadId: number): Promise<import(".prisma/client").Prisma.BatchPayload>;
    delete(id: number): Promise<{
        id: number;
        provinceId: number;
        ownerId: number;
        leadtype: string;
        leadStatus: string;
        salesPersonId: number;
        orgName: string;
        orgIdType: string;
        orgId: string;
        addrTitles: string;
        isDeleted: boolean;
        addr1: string;
        addr2: string;
        cityId: number;
        country: string;
        contactNIC: string;
        contactName: string;
        contactDesignation: string;
        contactEmail: string;
        contact1: string;
        contact2: string;
        adminFee: import("@prisma/client/runtime/library").Decimal;
        adminFeeType: string;
        vat: import("@prisma/client/runtime/library").Decimal;
        sscl: import("@prisma/client/runtime/library").Decimal;
        svat: import("@prisma/client/runtime/library").Decimal;
        discount: import("@prisma/client/runtime/library").Decimal;
        discountType: string;
        startDate: Date | null;
        endDate: Date | null;
    }>;
}
