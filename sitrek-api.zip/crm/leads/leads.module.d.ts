export declare class LeadsModule {
}
