import { Response } from 'express';
import { CreateLeadPayload, UpdateLeadPayload } from './dto/create-lead.dto';
import { LeadsService } from './leads.service';
export declare class LeadsController {
    private readonly service;
    constructor(service: LeadsService);
    create(payload: CreateLeadPayload, response: Response): Promise<Response<any, Record<string, any>>>;
    findAll(response: Response): Promise<Response<any, Record<string, any>>>;
    findOne(params: {
        id: number;
    }, response: Response): Promise<Response<any, Record<string, any>>>;
    findNotes(params: {
        id: number;
    }, response: Response): Promise<Response<any, Record<string, any>>>;
    update(payload: UpdateLeadPayload, response: Response): Promise<Response<any, Record<string, any>>>;
    deleteRateCard(payload: {
        cat: string;
        leadId: number;
    }, response: Response): Promise<Response<any, Record<string, any>>>;
    delete(payload: {
        id: number;
    }, response: Response): Promise<Response<any, Record<string, any>>>;
}
