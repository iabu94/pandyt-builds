import { sitrek_rate_cards } from '@prisma/client';
import { PrismaService } from 'src/prisma.service';
export declare class RateCardService {
    private prisma;
    constructor(prisma: PrismaService);
    getAll(): Promise<sitrek_rate_cards[]>;
}
