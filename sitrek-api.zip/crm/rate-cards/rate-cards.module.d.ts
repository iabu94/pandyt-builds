export declare class RateCardsModule {
}
