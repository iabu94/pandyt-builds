import { Response } from 'express';
import { RateCardService } from './rate-cards.service';
export declare class RateCardsController {
    private readonly service;
    constructor(service: RateCardService);
    findAll(response: Response): Promise<Response<any, Record<string, any>>>;
}
