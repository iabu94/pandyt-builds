import { Response } from 'express';
import { CustomersService } from './customers.service';
import { UpdateCustomerPayload } from './dto/create.customer.dto';
export declare class CustomersController {
    private readonly service;
    constructor(service: CustomersService);
    findAll(response: Response): Promise<Response<any, Record<string, any>>>;
    findOne(params: {
        id: number;
    }, response: Response): Promise<Response<any, Record<string, any>>>;
    customerExists(params: {
        code: string;
    }, response: Response): Promise<Response<any, Record<string, any>>>;
    update(payload: UpdateCustomerPayload, response: Response): Promise<Response<any, Record<string, any>>>;
    catch(error: any): Response<any, Record<string, any>>;
    delete(payload: {
        id: number;
    }, response: Response): Promise<Response<any, Record<string, any>>>;
}
