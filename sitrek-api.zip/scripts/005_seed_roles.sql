INSERT INTO `sitrek_roles` (`id`, `name`, `description`) VALUES (99, 'super_admin', 'Super Admin');
INSERT INTO `sitrek_roles` (`id`, `name`, `description`) VALUES (1, 'crm_manager', 'CRM Manager');
INSERT INTO `sitrek_roles` (`id`, `name`, `description`) VALUES (2, 'branch_manager', 'Branch Manager');
INSERT INTO `sitrek_roles` (`id`, `name`, `description`) VALUES (3, 'sales_manager', 'Sales Manager');
INSERT INTO `sitrek_roles` (`id`, `name`, `description`) VALUES (4, 'finance_manager', 'Finance Manager');