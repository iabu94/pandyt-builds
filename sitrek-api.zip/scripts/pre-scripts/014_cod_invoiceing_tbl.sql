CREATE TABLE `cod_invoiceing_tbl` ( 
  `id` INT AUTO_INCREMENT NOT NULL,
  `company_id` INT NULL,
  `invoice_date` DATETIME NULL,
  `satrt_date` DATETIME NULL,
  `end_date` DATETIME NULL,
  `user_id` INT NULL,
  `total_amount` FLOAT NULL,
  CONSTRAINT `PRIMARY` PRIMARY KEY (`id`)
)
ENGINE = InnoDB;
INSERT INTO `cod_invoiceing_tbl` (`id`, `company_id`, `invoice_date`, `satrt_date`, `end_date`, `user_id`, `total_amount`) VALUES (3, 1914, '2024-01-24 09:25:40', '2023-11-01 00:00:00', '2023-11-04 23:59:59', 2573, 296710);
INSERT INTO `cod_invoiceing_tbl` (`id`, `company_id`, `invoice_date`, `satrt_date`, `end_date`, `user_id`, `total_amount`) VALUES (4, 2117, '2024-05-04 14:50:21', '2024-04-01 00:00:00', '2024-04-30 23:59:59', 12672, 101486);
