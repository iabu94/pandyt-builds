CREATE TABLE `josyd_couriersystem_city` ( 
  `id` INT UNSIGNED AUTO_INCREMENT NOT NULL,
  `asset_id` INT UNSIGNED NOT NULL DEFAULT 0 ,
  `ordering` INT NOT NULL,
  `state` TINYINT NOT NULL,
  `checked_out` INT NOT NULL,
  `checked_out_time` DATETIME NOT NULL,
  `created_by` INT NOT NULL,
  `modified_by` INT NOT NULL,
  `cityname` VARCHAR(255) NOT NULL,
  `citycode` VARCHAR(255) NOT NULL,
  `postalcode` VARCHAR(255) NOT NULL,
  `location` VARCHAR(255) NOT NULL,
  `longitude` VARCHAR(255) NOT NULL,
  `latitude` VARCHAR(255) NOT NULL,
  CONSTRAINT `PRIMARY` PRIMARY KEY (`id`)
)
ENGINE = InnoDB;
CREATE INDEX `cityname` 
ON `josyd_couriersystem_city` (
  `cityname` ASC
);
CREATE INDEX `id` 
ON `josyd_couriersystem_city` (
  `id` ASC
);
