CREATE TABLE `josyd_couriersystem_route_sheet` ( 
  `id` INT UNSIGNED AUTO_INCREMENT NOT NULL,
  `asset_id` INT UNSIGNED NOT NULL DEFAULT 0 ,
  `ordering` INT NOT NULL DEFAULT 0 ,
  `state` TINYINT NOT NULL DEFAULT 1 ,
  `checked_out` INT NOT NULL DEFAULT 0 ,
  `checked_out_time` DATETIME NOT NULL,
  `created_by` INT NOT NULL,
  `modified_by` INT NOT NULL,
  `booking_number` VARCHAR(255) NOT NULL,
  `booking_id` INT NOT NULL,
  `status` VARCHAR(255) NOT NULL,
  `remarks` TEXT NULL,
  `signature` VARCHAR(255) NOT NULL DEFAULT ' ' ,
  `right_check` ENUM('0','1') NOT NULL DEFAULT 1 ,
  `barcode` VARCHAR(255) NOT NULL,
  `branch` INT NOT NULL,
  `nicnumber` VARCHAR(255) NOT NULL DEFAULT ' ' ,
  `date_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ,
  `name` VARCHAR(255) NOT NULL DEFAULT ' ' ,
  `mobile_web` INT NOT NULL DEFAULT 0 ,
  CONSTRAINT `PRIMARY` PRIMARY KEY (`id`),
  CONSTRAINT `booking_id_2` UNIQUE (`booking_id`, `barcode`)
)
ENGINE = InnoDB;
CREATE INDEX `barcode` 
ON `josyd_couriersystem_route_sheet` (
  `barcode` ASC
);
CREATE INDEX `booking_id` 
ON `josyd_couriersystem_route_sheet` (
  `booking_id` ASC
);
CREATE INDEX `booking_number` 
ON `josyd_couriersystem_route_sheet` (
  `booking_number` ASC
);
CREATE INDEX `date_time` 
ON `josyd_couriersystem_route_sheet` (
  `date_time` ASC
);
CREATE INDEX `status` 
ON `josyd_couriersystem_route_sheet` (
  `status` ASC
);
