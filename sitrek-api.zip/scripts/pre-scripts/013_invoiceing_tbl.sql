CREATE TABLE `invoiceing_tbl` ( 
  `id` INT AUTO_INCREMENT NOT NULL,
  `company_id` INT NULL,
  `invoice_date` DATETIME NULL,
  `satrt_date` DATETIME NULL,
  `end_date` DATETIME NULL,
  `user_id` INT NULL,
  `total_amount` FLOAT NULL,
  CONSTRAINT `PRIMARY` PRIMARY KEY (`id`)
)
ENGINE = InnoDB;
INSERT INTO `invoiceing_tbl` (`id`, `company_id`, `invoice_date`, `satrt_date`, `end_date`, `user_id`, `total_amount`) VALUES (34, 337, '2023-12-09 09:26:35', '2023-11-01 00:00:00', '2023-11-30 23:59:59', 2573, 783271);
INSERT INTO `invoiceing_tbl` (`id`, `company_id`, `invoice_date`, `satrt_date`, `end_date`, `user_id`, `total_amount`) VALUES (35, 95, '2023-12-27 14:38:52', '2023-12-01 00:00:00', '2023-12-27 23:59:59', 829, 1840);
INSERT INTO `invoiceing_tbl` (`id`, `company_id`, `invoice_date`, `satrt_date`, `end_date`, `user_id`, `total_amount`) VALUES (38, 3915, '2024-05-01 10:49:05', '2024-04-01 00:00:00', '2024-04-30 23:59:59', 829, 0);
INSERT INTO `invoiceing_tbl` (`id`, `company_id`, `invoice_date`, `satrt_date`, `end_date`, `user_id`, `total_amount`) VALUES (39, 263, '2024-05-04 14:45:35', '2024-04-01 00:00:00', '2024-04-30 23:59:59', 12672, 310830);
INSERT INTO `invoiceing_tbl` (`id`, `company_id`, `invoice_date`, `satrt_date`, `end_date`, `user_id`, `total_amount`) VALUES (40, 204, '2024-05-04 14:48:10', '2024-04-01 00:00:00', '2024-04-30 23:59:59', 12672, 57230);
INSERT INTO `invoiceing_tbl` (`id`, `company_id`, `invoice_date`, `satrt_date`, `end_date`, `user_id`, `total_amount`) VALUES (41, 177, '2024-06-13 12:28:05', '2024-05-01 00:00:00', '2024-05-31 23:59:59', 830, 22280);
