CREATE TABLE `josyd_couriersystem_company_profile` ( 
  `id` INT AUTO_INCREMENT NOT NULL,
  `ordering` INT NOT NULL,
  `state` TINYINT NOT NULL,
  `checked_out` INT NOT NULL,
  `checked_out_time` DATETIME NOT NULL,
  `created_by` INT NOT NULL,
  `modified_by` INT NOT NULL,
  `company_name` VARCHAR(255) NOT NULL,
  `phone` BIGINT NOT NULL,
  `fax` VARCHAR(255) NOT NULL,
  `email_id` VARCHAR(255) NOT NULL,
  `address` TEXT NOT NULL,
  `website` VARCHAR(255) NOT NULL,
  `logo` TEXT NOT NULL,
  `company_code` VARCHAR(255) NOT NULL,
  `work_group` INT NOT NULL,
  `corporatehead` INT NOT NULL,
  `group` INT NOT NULL,
  `priceplan` ENUM('1','2') NOT NULL,
  `fuel` ENUM('1','2') NOT NULL,
  `waybill` ENUM('1','2') NOT NULL,
  `fuelrate` INT NOT NULL,
  `pickupcommission` INT NOT NULL,
  `city` INT NOT NULL,
  `admin_fee` INT NOT NULL DEFAULT 0 ,
  `created_date` DATETIME NULL,
  `modified_date` DATETIME NULL,
  `ben_name` VARCHAR(150) NULL,
  `bnk_name` VARCHAR(100) NULL,
  `bnk_ac_number` VARCHAR(100) NULL,
  `bnk_branch` VARCHAR(100) NULL,
  `tax_type_id` INT NULL,
  `invoice_type_id` TINYINT NOT NULL DEFAULT 1 ,
  CONSTRAINT `PRIMARY` PRIMARY KEY (`id`)
)
ENGINE = InnoDB;
CREATE INDEX `checked_out` 
ON `josyd_couriersystem_company_profile` (
  `checked_out` ASC
);
CREATE INDEX `city` 
ON `josyd_couriersystem_company_profile` (
  `city` ASC
);
CREATE INDEX `corporatehead` 
ON `josyd_couriersystem_company_profile` (
  `corporatehead` ASC
);
CREATE INDEX `created_by` 
ON `josyd_couriersystem_company_profile` (
  `created_by` ASC
);
CREATE INDEX `id` 
ON `josyd_couriersystem_company_profile` (
  `id` ASC
);
CREATE INDEX `modified_by` 
ON `josyd_couriersystem_company_profile` (
  `modified_by` ASC
);
CREATE INDEX `ordering` 
ON `josyd_couriersystem_company_profile` (
  `ordering` ASC
);
CREATE INDEX `state` 
ON `josyd_couriersystem_company_profile` (
  `state` ASC
);
