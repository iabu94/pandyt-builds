CREATE TABLE `josyd_couriersystem_prepareroutesheet` ( 
  `id` INT UNSIGNED AUTO_INCREMENT NOT NULL,
  `asset_id` INT UNSIGNED NOT NULL DEFAULT 0 ,
  `ordering` INT NOT NULL,
  `state` TINYINT NOT NULL,
  `checked_out` INT NOT NULL,
  `checked_out_time` DATETIME NOT NULL,
  `created_by` INT NOT NULL,
  `modified_by` INT NOT NULL,
  `staff` INT NOT NULL,
  `route_name` INT NOT NULL,
  `booking_id` INT NOT NULL,
  `date_time` DATETIME NOT NULL,
  `status` INT NOT NULL,
  `remarks` MEDIUMTEXT NOT NULL,
  `barcode` VARCHAR(16) NULL,
  `booking_number` VARCHAR(45) NULL,
  `nicnumber` VARCHAR(200) NULL,
  `name` VARCHAR(200) NULL,
  `vehicle_id` INT NULL,
  CONSTRAINT `PRIMARY` PRIMARY KEY (`id`)
)
ENGINE = InnoDB;
CREATE INDEX `booking_id` 
ON `josyd_couriersystem_prepareroutesheet` (
  `booking_id` ASC
);
CREATE INDEX `date_time` 
ON `josyd_couriersystem_prepareroutesheet` (
  `date_time` ASC
);
CREATE INDEX `idx_josyd_couriersystem_prepareroutesheet_barcode` 
ON `josyd_couriersystem_prepareroutesheet` (
  `barcode` ASC
);
CREATE INDEX `idx_josyd_couriersystem_prepareroutesheet_booking_number` 
ON `josyd_couriersystem_prepareroutesheet` (
  `booking_number` ASC
);
CREATE INDEX `idx_josyd_couriersystem_prepareroutesheet_created_by` 
ON `josyd_couriersystem_prepareroutesheet` (
  `created_by` ASC
);
CREATE INDEX `idx_josyd_couriersystem_prepareroutesheet_modified_by` 
ON `josyd_couriersystem_prepareroutesheet` (
  `modified_by` ASC
);
CREATE INDEX `route_name` 
ON `josyd_couriersystem_prepareroutesheet` (
  `route_name` ASC
);
CREATE INDEX `staff` 
ON `josyd_couriersystem_prepareroutesheet` (
  `staff` ASC
);
