CREATE TABLE `josyd_couriersystem_booking` ( 
  `id` INT UNSIGNED AUTO_INCREMENT NOT NULL,
  `asset_id` INT UNSIGNED NOT NULL DEFAULT 0 ,
  `state` TINYINT NOT NULL,
  `created_by` INT NOT NULL,
  `sendername` VARCHAR(255) NOT NULL,
  `senderphone` VARCHAR(20) NOT NULL,
  `senderemail` VARCHAR(255) NOT NULL,
  `senderaddress` MEDIUMTEXT NOT NULL,
  `receivername` VARCHAR(255) NOT NULL,
  `receiverphone` VARCHAR(30) NOT NULL,
  `receiveremail` VARCHAR(255) NOT NULL,
  `receiveraddress` MEDIUMTEXT NOT NULL,
  `product` TEXT NOT NULL,
  `weight` FLOAT NOT NULL,
  `quantity` FLOAT NOT NULL,
  `price` FLOAT NOT NULL,
  `totalprice` FLOAT NOT NULL,
  `sender_details` INT NOT NULL,
  `receiver_details` INT NOT NULL,
  `sender_city` INT NOT NULL,
  `receiver_city` INT NOT NULL,
  `is_cash_paid` VARCHAR(255) NOT NULL,
  `payment_card_type` INT NOT NULL,
  `date_time` DATETIME NOT NULL,
  `user` INT NOT NULL,
  `addkg` FLOAT NOT NULL,
  `prodid` MEDIUMTEXT NOT NULL,
  `checked_out` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ,
  `modified_by` INT NULL DEFAULT 0 ,
  `grand_total` FLOAT NULL,
  `booking_id` VARCHAR(255) NULL,
  `comments` LONGTEXT NULL,
  `senderlandmark` MEDIUMTEXT NOT NULL,
  `receiverlandmark` MEDIUMTEXT NOT NULL,
  `pickup` INT NOT NULL,
  `pickuptime` DATETIME NOT NULL,
  `adjustment` FLOAT NOT NULL,
  `booking_from` INT NOT NULL,
  `dhlrate` INT NOT NULL,
  `dutyamount` INT NOT NULL,
  `waybill` VARCHAR(255) NOT NULL,
  `dhlaccount` INT NOT NULL,
  `company` INT NOT NULL,
  `barcodelink` INT NOT NULL,
  `barcodes` VARCHAR(255) NOT NULL,
  `modified_on` DATETIME NULL DEFAULT '1111-11-11 11:11:11' ,
  `printed_status` VARCHAR(3) NOT NULL DEFAULT 'No' ,
  `r_branch` INT NULL,
  `return_status` TINYINT NOT NULL DEFAULT 0 ,
  `isPaidOnline` INT NOT NULL DEFAULT 0 ,
  `tra_ref_num` VARCHAR(20) NULL,
  `ReturnedToCust_status` INT NOT NULL DEFAULT 0 ,
  `paid_to_customer` TINYINT NOT NULL DEFAULT 0 ,
  `item_damaged` TINYINT NOT NULL DEFAULT 0 ,
  `item_damaged_date` DATETIME NULL,
  `item_damaged_comment` LONGTEXT NULL,
  `item_damaged_user` INT NULL,
  `invoice_id` INT NULL,
  `cod_invoice_id` INT NULL,
  `rtn_price` FLOAT NULL,
  `rtn_add_kg` FLOAT NULL,
  `rtn_grand_total` FLOAT NULL,
  CONSTRAINT `PRIMARY` PRIMARY KEY (`id`)
)
ENGINE = InnoDB;
CREATE INDEX `booking_from` 
ON `josyd_couriersystem_booking` (
  `booking_from` ASC
);
CREATE INDEX `booking_id` 
ON `josyd_couriersystem_booking` (
  `booking_id` ASC
);
CREATE INDEX `company` 
ON `josyd_couriersystem_booking` (
  `company` ASC
);
CREATE INDEX `created_by` 
ON `josyd_couriersystem_booking` (
  `created_by` ASC
);
CREATE INDEX `date_time` 
ON `josyd_couriersystem_booking` (
  `date_time` ASC
);
CREATE INDEX `id` 
ON `josyd_couriersystem_booking` (
  `id` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_barcodelink` 
ON `josyd_couriersystem_booking` (
  `barcodelink` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_barcodes` 
ON `josyd_couriersystem_booking` (
  `barcodes` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_company` 
ON `josyd_couriersystem_booking` (
  `company` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_date_time` 
ON `josyd_couriersystem_booking` (
  `date_time` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_dutyamount` 
ON `josyd_couriersystem_booking` (
  `dutyamount` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_paid_to_customer` 
ON `josyd_couriersystem_booking` (
  `paid_to_customer` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_r_branch` 
ON `josyd_couriersystem_booking` (
  `r_branch` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_receivername` 
ON `josyd_couriersystem_booking` (
  `receivername` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_return_status` 
ON `josyd_couriersystem_booking` (
  `return_status` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_ReturnedToCust_status` 
ON `josyd_couriersystem_booking` (
  `ReturnedToCust_status` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_sendername` 
ON `josyd_couriersystem_booking` (
  `sendername` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_state` 
ON `josyd_couriersystem_booking` (
  `state` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_waybill` 
ON `josyd_couriersystem_booking` (
  `waybill` ASC
);
CREATE INDEX `idx_josyd_couriersystem_booking_weight` 
ON `josyd_couriersystem_booking` (
  `weight` ASC
);
CREATE INDEX `invoice_id` 
ON `josyd_couriersystem_booking` (
  `invoice_id` ASC
);
CREATE INDEX `is_cash_paid` 
ON `josyd_couriersystem_booking` (
  `is_cash_paid` ASC
);
CREATE INDEX `josyd_couriersystem_booking_ibfk_2_idx` 
ON `josyd_couriersystem_booking` (
  `cod_invoice_id` ASC
);
CREATE INDEX `modified_on` 
ON `josyd_couriersystem_booking` (
  `modified_on` ASC
);
CREATE INDEX `payment_card_type` 
ON `josyd_couriersystem_booking` (
  `payment_card_type` ASC
);
CREATE INDEX `pickup` 
ON `josyd_couriersystem_booking` (
  `pickup` ASC
);
CREATE INDEX `receiver_city` 
ON `josyd_couriersystem_booking` (
  `receiver_city` ASC
);
CREATE INDEX `sender_city` 
ON `josyd_couriersystem_booking` (
  `sender_city` ASC
);
CREATE INDEX `user` 
ON `josyd_couriersystem_booking` (
  `user` ASC
);
ALTER TABLE `josyd_couriersystem_booking` ADD CONSTRAINT `josyd_couriersystem_booking_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoiceing_tbl` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE `josyd_couriersystem_booking` ADD CONSTRAINT `josyd_couriersystem_booking_ibfk_2` FOREIGN KEY (`cod_invoice_id`) REFERENCES `cod_invoiceing_tbl` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
