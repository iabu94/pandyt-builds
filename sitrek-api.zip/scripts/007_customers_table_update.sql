ALTER TABLE sitrek_customers
ADD josyd_couriersystem_company_profile_id INT;

ALTER TABLE sitrek_customers
ADD CONSTRAINT josyd_couriersystem_company_profile_id
FOREIGN KEY (josyd_couriersystem_company_profile_id)
REFERENCES josyd_couriersystem_company_profile (id);
