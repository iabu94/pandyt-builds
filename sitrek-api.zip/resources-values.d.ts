export declare const RESOURCE_DATA: {
    leadType: string[];
    leadStatus: string[];
    idType: string[];
    categories: string[];
    paymentTypes: string[];
    rateCardDemarcations: string[];
};
