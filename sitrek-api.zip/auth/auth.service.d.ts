import { JwtService } from '@nestjs/jwt';
import { PrismaService } from 'src/prisma.service';
import { DataSource } from 'typeorm';
export declare class AuthService {
    private prisma;
    private dataSource;
    private jwtService;
    constructor(prisma: PrismaService, dataSource: DataSource, jwtService: JwtService);
    prismaOutput(userId: number): Promise<{
        userInfo: {
            id: number;
            name: string;
            email: string;
        };
        permissions: string[];
    }>;
    getUserPermissionsQuery(userId: number): Promise<{
        userInfo: {
            id: any;
            name: any;
            email: any;
        };
        permissions: any[];
    }>;
    login({ username, password }: any): Promise<{
        token: string;
    }>;
}
