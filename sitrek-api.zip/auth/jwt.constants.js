"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JWT_SECRET = void 0;
exports.JWT_SECRET = '4563234@#2';
//# sourceMappingURL=jwt.constants.js.map