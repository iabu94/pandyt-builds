"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const bcrypt = require("bcrypt");
const prisma_service_1 = require("../prisma.service");
const typeorm_1 = require("typeorm");
let AuthService = class AuthService {
    constructor(prisma, dataSource, jwtService) {
        this.prisma = prisma;
        this.dataSource = dataSource;
        this.jwtService = jwtService;
    }
    async prismaOutput(userId) {
        const userInfo = await this.prisma.josyd_users.findUnique({
            where: {
                id: userId,
            },
            select: {
                id: true,
                name: true,
                email: true,
                sitrek_user_roles_permissions: {
                    select: {
                        sitrek_permissions: {
                            select: {
                                name: true,
                            },
                        },
                    },
                },
            },
        });
        return {
            userInfo: {
                id: userInfo.id,
                name: userInfo.name,
                email: userInfo.email,
            },
            permissions: userInfo.sitrek_user_roles_permissions.map((p) => p.sitrek_permissions.name),
        };
    }
    async getUserPermissionsQuery(userId) {
        const userInfo = await this.dataSource.query(`SELECT u.id, u.name, u.email, p.name as permission_name
      FROM josyd_users u
      LEFT JOIN sitrek_user_roles_permissions urp ON urp.userId = u.id
      LEFT JOIN sitrek_permissions p ON urp.permissionId = p.id
      WHERE u.id = ?;
      `, [userId]);
        return {
            userInfo: {
                id: userInfo[0].id,
                name: userInfo[0].name,
                email: userInfo[0].email,
            },
            permissions: [...userInfo.map((p) => p.permission_name)],
        };
    }
    async login({ username, password }) {
        const res = await this.dataSource.query(`
      SELECT id, username, email, name, password
      FROM josyd_users
      WHERE username = ?
      LIMIT 1;`, [username]);
        const isValid = await bcrypt.compare(password, res[0].password.replace('$2y$', '$2b$'));
        if (!isValid) {
            throw new Error('Invalid username or password');
        }
        const token = this.jwtService.sign({ ...res[0] });
        return { token };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        typeorm_1.DataSource,
        jwt_1.JwtService])
], AuthService);
//# sourceMappingURL=auth.service.js.map