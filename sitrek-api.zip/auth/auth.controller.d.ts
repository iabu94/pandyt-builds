import { Response } from 'express';
import { AuthService } from './auth.service';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    getUserPermissions(req: any, response: Response): Promise<Response<any, Record<string, any>>>;
    login(req: any, response: Response, body: any): Promise<Response<any, Record<string, any>>>;
}
