import { Response } from 'express';
export declare class FileController {
    uploadFile(file: Express.Multer.File): {
        message: string;
        filePath: string;
    };
    getFile(filename: string, res: Response): void;
}
