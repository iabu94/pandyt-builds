export declare class CitiesModule {
}
