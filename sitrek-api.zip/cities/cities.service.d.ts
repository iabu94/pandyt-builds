import { DataSource } from 'typeorm';
import { District } from './entities/cities.entity';
export declare class CitiesService {
    private dataSource;
    constructor(dataSource: DataSource);
    getProvinces(): Promise<any>;
    getDistricts(provinceId?: number): Promise<District[]>;
    getCities(districtId?: number): Promise<any>;
}
