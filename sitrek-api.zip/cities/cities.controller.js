"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CitiesController = void 0;
const common_1 = require("@nestjs/common");
const http_status_codes_1 = require("http-status-codes");
const cities_service_1 = require("./cities.service");
let CitiesController = class CitiesController {
    constructor(service) {
        this.service = service;
    }
    async getProvinces(response) {
        try {
            const result = await this.service.getProvinces();
            return response.status(http_status_codes_1.StatusCodes.OK).json({
                statusCode: http_status_codes_1.StatusCodes.OK,
                message: 'Retrieved all provinces successfully',
                body: result,
            });
        }
        catch (error) {
            console.log(error, 'error');
            return response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                message: 'Something went wrong',
                error: (0, http_status_codes_1.getReasonPhrase)(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR),
                statusCode: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
            });
        }
    }
    async getDistricts(provinceId, response) {
        try {
            const result = await this.service.getDistricts(Number(provinceId));
            return response.status(http_status_codes_1.StatusCodes.OK).json({
                statusCode: http_status_codes_1.StatusCodes.OK,
                message: 'Retrieved all districts successfully',
                body: result,
            });
        }
        catch (error) {
            console.log(error, 'error');
            return response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                message: 'Something went wrong',
                error: (0, http_status_codes_1.getReasonPhrase)(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR),
                statusCode: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
            });
        }
    }
    async getCities(districtId, response) {
        try {
            const result = await this.service.getCities(Number(districtId));
            return response.status(http_status_codes_1.StatusCodes.OK).json({
                statusCode: http_status_codes_1.StatusCodes.OK,
                message: 'Retrieved all cities successfully',
                body: result,
            });
        }
        catch (error) {
            console.log(error, 'error');
            return response.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                message: 'Something went wrong',
                error: (0, http_status_codes_1.getReasonPhrase)(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR),
                statusCode: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
            });
        }
    }
};
exports.CitiesController = CitiesController;
__decorate([
    (0, common_1.Get)('provinces'),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], CitiesController.prototype, "getProvinces", null);
__decorate([
    (0, common_1.Get)('districts'),
    __param(0, (0, common_1.Query)('provinceId')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], CitiesController.prototype, "getDistricts", null);
__decorate([
    (0, common_1.Get)('cities'),
    __param(0, (0, common_1.Query)('districtId')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], CitiesController.prototype, "getCities", null);
exports.CitiesController = CitiesController = __decorate([
    (0, common_1.Controller)('resource'),
    __metadata("design:paramtypes", [cities_service_1.CitiesService])
], CitiesController);
//# sourceMappingURL=cities.controller.js.map