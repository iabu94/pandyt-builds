import { Response } from 'express';
import { CitiesService } from './cities.service';
export declare class CitiesController {
    private readonly service;
    constructor(service: CitiesService);
    getProvinces(response: Response): Promise<Response<any, Record<string, any>>>;
    getDistricts(provinceId: string, response: Response): Promise<Response<any, Record<string, any>>>;
    getCities(districtId: string, response: Response): Promise<Response<any, Record<string, any>>>;
}
