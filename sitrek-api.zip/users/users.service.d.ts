import { DataSource } from 'typeorm';
import { User } from './entities/user.entity';
export declare class UsersService {
    private dataSource;
    constructor(dataSource: DataSource);
    findAll(): Promise<User[]>;
    findById(id: number): Promise<User>;
}
