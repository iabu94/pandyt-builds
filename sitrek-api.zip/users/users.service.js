"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("typeorm");
let UsersService = class UsersService {
    constructor(dataSource) {
        this.dataSource = dataSource;
    }
    async findAll() {
        const result = await this.dataSource.query(`SELECT 
      r.id as id,
      r.privacy as privacy,
      r.firstname as firstname,
      r.secondname as secondname,
      r.lastname as lastname,
      r.avatar as avatar,
      r.params as params,
      r.facebook_id as facebookId,
      r.twitter_id as twitterId,
      r.google_id as googleId,
      r.linkedin_id as linkedinId,
      r.instagram_id as instagramId,
      r.address as address,
      r.phone_number as phoneNumber,
      r.nic as nic,
      r.type as type,
      u.name as name,
      u.username as username,
      u.email as email
    FROM josyd_jsn_users as r
    INNER JOIN josyd_users as u ON r.id = u.id
    WHERE u.email like '%certislanka.com%' OR u.email like '%sitrekgroup.com%'`);
        return result;
    }
    async findById(id) {
        const result = await this.dataSource.query(`SELECT 
      r.id as id,
      r.privacy as privacy,
      r.firstname as firstname,
      r.secondname as secondname,
      r.lastname as lastname,
      r.avatar as avatar,
      r.params as params,
      r.facebook_id as facebookId,
      r.twitter_id as twitterId,
      r.google_id as googleId,
      r.linkedin_id as linkedinId,
      r.instagram_id as instagramId,
      r.address as address,
      r.phone_number as phoneNumber,
      r.nic as nic,
      r.type as type,
      u.name as name,
      u.username as username,
      u.email as email
    FROM josyd_jsn_users as r
    INNER JOIN josyd_users as u ON r.id = u.id
    WHERE r.id = ?`, [id]);
        if (result.length === 0) {
            throw new Error('User not found');
        }
        return result[0];
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeorm_1.DataSource])
], UsersService);
//# sourceMappingURL=users.service.js.map