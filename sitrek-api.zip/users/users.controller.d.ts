import { Response } from 'express';
import { UsersService } from './users.service';
export declare class UsersController {
    private readonly service;
    constructor(service: UsersService);
    findAll(response: Response): Promise<Response<any, Record<string, any>>>;
    findById(params: {
        id: number;
    }, response: Response): Promise<Response<any, Record<string, any>>>;
}
