export declare class UserRolesPermissionsModule {
}
