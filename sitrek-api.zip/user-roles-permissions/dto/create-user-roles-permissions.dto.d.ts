export declare class CreateUserRolesPermissionsDto {
    roleId: number;
    permissionId: number;
}
export declare class CreateUserRolePermissionRequest {
    items: CreateUserRolesPermissionsDto[];
    userId: number;
}
