export declare class UserRolesPermissionsDto {
    userId: number;
    user: string;
    role: string;
    permissions: string[];
}
