"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRolesPermissionsDto = void 0;
class UserRolesPermissionsDto {
}
exports.UserRolesPermissionsDto = UserRolesPermissionsDto;
//# sourceMappingURL=user-roles-permissions.dto.js.map