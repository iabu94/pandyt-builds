import { DataSource } from 'typeorm';
import { CreateUserRolesPermissionsDto } from './dto/create-user-roles-permissions.dto';
import { UserRolesPermissionsDto } from './dto/user-roles-permissions.dto';
import { UserRolesPermissions } from './entities/user-roles-permissions.entity';
export declare class UserRolesPermissionsService {
    private dataSource;
    constructor(dataSource: DataSource);
    findAll(): Promise<UserRolesPermissionsDto[]>;
    deleteAllByUser(userId: number): Promise<void>;
    create(userId: number, { roleId, permissionId }: CreateUserRolesPermissionsDto): Promise<UserRolesPermissions>;
    findOne(id: number): Promise<UserRolesPermissions>;
    getByUserId(id: number): Promise<UserRolesPermissions[]>;
}
