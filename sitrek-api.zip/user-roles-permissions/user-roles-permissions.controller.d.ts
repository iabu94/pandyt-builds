import { Response } from 'express';
import { CreateUserRolePermissionRequest } from './dto/create-user-roles-permissions.dto';
import { UserRolesPermissionsService } from './user-roles-permissions.service';
export declare class UserRolesPermissionsController {
    private readonly service;
    constructor(service: UserRolesPermissionsService);
    create(response: Response, createRequest: CreateUserRolePermissionRequest): Promise<Response<any, Record<string, any>>>;
    findAll(response: Response): Promise<Response<any, Record<string, any>>>;
    findAllByUser(params: any, response: Response): Promise<Response<any, Record<string, any>>>;
}
