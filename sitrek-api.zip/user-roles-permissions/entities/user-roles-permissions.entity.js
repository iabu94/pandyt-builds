"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRolesPermissions = void 0;
class UserRolesPermissions {
}
exports.UserRolesPermissions = UserRolesPermissions;
//# sourceMappingURL=user-roles-permissions.entity.js.map