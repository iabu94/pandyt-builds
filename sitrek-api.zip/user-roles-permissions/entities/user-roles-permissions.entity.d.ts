import { Permission } from 'src/role-permissions/entities/role-permissions.entity';
export declare class UserRolesPermissions {
    id: number;
    userId: number;
    roleId: number;
    roleName: string;
    username: string;
    description: string;
    permissions: Permission[];
}
