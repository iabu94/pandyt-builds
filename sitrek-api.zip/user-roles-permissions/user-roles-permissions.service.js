"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRolesPermissionsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("typeorm");
const tableName = 'sitrek_user_roles_permissions';
let UserRolesPermissionsService = class UserRolesPermissionsService {
    constructor(dataSource) {
        this.dataSource = dataSource;
    }
    async findAll() {
        const result = await this.dataSource.query(`SELECT 
    u.id AS userId,
    u.name AS user,
    r.name AS role,
    r.description AS description,
    IF(r.id IS NOT NULL, 
       CONCAT(
           '[', 
           GROUP_CONCAT(DISTINCT CONCAT('{"name": "', REPLACE(IFNULL(p.name, ''), '"', '\"'), '", "description": "', REPLACE(IFNULL(p.description, ''), '"', '\"'), '"}')), 
           ']'
       ),
       '[]'
    ) AS permissions
FROM josyd_users AS u
LEFT JOIN (
    SELECT 
        urp.userId,
        MIN(urp.roleId) AS min_role_id
    FROM ${tableName} AS urp
    GROUP BY urp.userId
) AS FirstRole ON u.id = FirstRole.userId
LEFT JOIN ${tableName} AS urp ON u.id = urp.userId AND urp.roleId = FirstRole.min_role_id
LEFT JOIN sitrek_roles AS r ON r.id = urp.roleId
LEFT JOIN sitrek_permissions AS p ON p.id = urp.permissionId
GROUP BY u.id, u.name, r.name, r.description;
;
`);
        return result.map((user) => ({
            ...user,
            permissions: user.permissions ? JSON.parse(user.permissions) : [],
        }));
    }
    async deleteAllByUser(userId) {
        await this.dataSource.query(`DELETE FROM ${tableName} WHERE userId = ?`, [
            userId,
        ]);
    }
    async create(userId, { roleId, permissionId }) {
        const result = await this.dataSource.query(`INSERT INTO ${tableName} (userId, roleId, permissionId)
        VALUES (?, ?, ?)`, [userId, roleId, permissionId]);
        return await this.findOne(result.insertId);
    }
    async findOne(id) {
        const result = await this.dataSource.query(`SELECT * FROM ${tableName} WHERE id = ?`, [id]);
        return result;
    }
    async getByUserId(id) {
        const result = await this.dataSource.query(`SELECT 
      urp.userId AS userId, 
      u.username AS userName, 
      urp.roleId AS roleId, 
      r.name AS roleName,
      r.description AS description,
      CONCAT('[', GROUP_CONCAT(
        CONCAT('{"id": ', p.id, ', "name": "', p.name, '", "description": "', p.description, '"}')
      ), ']') AS permissions
FROM ${tableName} AS urp
JOIN josyd_users AS u ON u.id = urp.userId
JOIN sitrek_roles AS r ON r.id = urp.roleId
JOIN sitrek_permissions AS p ON p.id = urp.permissionId
WHERE urp.userId = ?
GROUP BY urp.userId, u.username, urp.roleId, r.name, r.description;
`, [id]);
        return result.map((role) => ({
            ...role,
            permissions: JSON.parse(role.permissions),
        }));
    }
};
exports.UserRolesPermissionsService = UserRolesPermissionsService;
exports.UserRolesPermissionsService = UserRolesPermissionsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeorm_1.DataSource])
], UserRolesPermissionsService);
//# sourceMappingURL=user-roles-permissions.service.js.map