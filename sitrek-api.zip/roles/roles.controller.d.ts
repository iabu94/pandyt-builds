import { Response } from 'express';
import { RolesService } from './roles.service';
export declare class RolesController {
    private readonly service;
    constructor(service: RolesService);
    findAll(response: Response): Promise<Response<any, Record<string, any>>>;
}
