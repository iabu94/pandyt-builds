import { DataSource } from 'typeorm';
import { Role } from './entities/role.entity';
export declare class RolesService {
    private dataSource;
    constructor(dataSource: DataSource);
    findAll(): Promise<Role[]>;
}
