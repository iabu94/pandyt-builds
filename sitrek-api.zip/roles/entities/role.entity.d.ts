export declare class Role {
    id: number;
    name: string;
    description: string;
}
