"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Role = void 0;
class Role {
}
exports.Role = Role;
//# sourceMappingURL=role.entity.js.map