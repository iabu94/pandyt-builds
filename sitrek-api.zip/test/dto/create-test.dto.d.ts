export declare class CreateTestDto {
    id: number;
    name: string;
    email: string;
}
