"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateTestDto = void 0;
class CreateTestDto {
}
exports.CreateTestDto = CreateTestDto;
//# sourceMappingURL=create-test.dto.js.map