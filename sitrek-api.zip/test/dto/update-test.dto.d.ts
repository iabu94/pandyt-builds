import { CreateTestDto } from './create-test.dto';
declare const UpdateTestDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateTestDto>>;
export declare class UpdateTestDto extends UpdateTestDto_base {
}
export {};
