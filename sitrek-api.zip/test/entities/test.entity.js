"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Test = void 0;
class Test {
}
exports.Test = Test;
//# sourceMappingURL=test.entity.js.map