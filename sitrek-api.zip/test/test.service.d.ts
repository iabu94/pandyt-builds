import { DataSource } from 'typeorm';
import { CreateTestDto } from './dto/create-test.dto';
import { UpdateTestDto } from './dto/update-test.dto';
import { Test } from './entities/test.entity';
export declare class TestService {
    private dataSource;
    constructor(dataSource: DataSource);
    getPassword(): Promise<boolean>;
    create({ name, email }: CreateTestDto): Promise<Test>;
    findAll(): Promise<Test[]>;
    findOne(id: number): Promise<Test>;
    update(id: number, { name, email }: UpdateTestDto): Promise<Test>;
    remove(id: number): boolean;
}
