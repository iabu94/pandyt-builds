import { Response } from 'express';
import { CreateTestDto } from './dto/create-test.dto';
import { UpdateTestDto } from './dto/update-test.dto';
import { TestService } from './test.service';
export declare class TestController {
    private readonly testService;
    constructor(testService: TestService);
    create(request: any, response: Response, createTestDto: CreateTestDto): Promise<Response<any, Record<string, any>>>;
    findAll(request: any, response: Response): Promise<Response<any, Record<string, any>>>;
    findOne(request: any, response: Response, id: string): Promise<Response<any, Record<string, any>>>;
    update(request: any, response: Response, id: string, updateTestDto: UpdateTestDto): Promise<Response<any, Record<string, any>>>;
    getPassword(request: any, response: Response): Promise<Response<any, Record<string, any>>>;
    remove(request: any, response: Response, id: string): Promise<Response<any, Record<string, any>>>;
}
