export declare class TestModule {
}
