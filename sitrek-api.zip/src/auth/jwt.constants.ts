export const JWT_SECRET = '4563234@#2';
