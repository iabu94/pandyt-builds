export class Test {
  id: number;
  name: string;
  email: string;
}
