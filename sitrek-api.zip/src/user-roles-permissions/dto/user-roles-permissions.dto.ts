export class UserRolesPermissionsDto {
  userId: number;
  user: string;
  role: string;
  permissions: string[];
}
